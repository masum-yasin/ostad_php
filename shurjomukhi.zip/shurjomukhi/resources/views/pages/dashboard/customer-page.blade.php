@extends('layout.sidenav-layout')
@section('admin')
@include('components.customer.customer-list')
    @include('components.customer.customer-delete')
    @include('components.customer.customer-create')
    @include('components.customer.customer-update')
@endsection