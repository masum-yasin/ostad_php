<!-- Modal -->
    <div class="modal fade animated zoomIn" id="create-modal" tabindex="-1" role="dialog" aria-labelledby="createLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title" id="createLabel">Create Category</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <form id="save-form">
                        <div class="container">
                            <div class="row">
                                <div class="col-12 p-1">
                                    <label class="form-label">Category Name *</label>
                                    <input type="text" class="form-control" id="categoryName" name="category" placeholder="Enter category name" required>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- Modal Footer with Close + Submit -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal" id="modal-close-btn">
                        Close
                    </button>
                    <button type="button" class="btn btn-primary" id="createSubmitBtn">
                        Submit
                    </button>
                </div>
            </div>
        </div>
      </div>

<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  // send cookies with every axios request
  axios.defaults.withCredentials = true;

  document.getElementById('createSubmitBtn').addEventListener('click', async (event) => {
    event.preventDefault();

    const categoryName = document.getElementById('categoryName').value?.trim();
    if (!categoryName) {
      return Swal.fire({icon:'error', title:'Oops...', text:'Category name is required!'});
    }

    try {
      const res = await axios.post('/create-category', { category: categoryName }, { withCredentials: true });

      // axios will only be here if status is 2xx
      document.getElementById('modal-close-btn').click();
      Swal.fire({ icon:'success', title:'Success!', text: res.data.message || 'Category created successfully' });
      document.getElementById('save-form').reset();
      await getList(); // refresh the category list
    } catch (err) {
      // show backend-provided reason if any
      const msg = err?.response?.data?.error || err?.response?.data?.message || 'An error occurred while creating the category';
      Swal.fire({ icon:'error', title:'Error', text: msg });
      console.error('Create category failed:', err?.response || err);
    }
  });
</script>


