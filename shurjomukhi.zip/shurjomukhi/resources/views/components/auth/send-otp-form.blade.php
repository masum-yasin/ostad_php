<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="{{asset('backend/asset/css/main.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('backend/asset/css/progress.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('backend/asset/css/toastify.min.css')}}">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <title>OTP SEND</title>
    <style>
      
        
        .material-half-bg {
            position: fixed;
            width: 100%;
            height: 100%;
            background: url('your-background-image.jpg') center/cover no-repeat;
            z-index: -1;
            background-color: #009688;
        }
        
        .material-half-bg .cover {
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }
        
        .registration-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            width: 100%;
            padding: 20px;
            box-sizing: border-box;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 20px;
        }
        
        .logo h1 {
            color: #fff;
            font-size: 32px;
        }
        
        .registration-box {
            width: 100%;
            max-width: 500px;
            background-color: #fff;
            box-shadow: 0px 29px 147.5px 102.5px rgba(0, 0, 0, 0.05), 
                        0px 29px 95px 0px rgba(0, 0, 0, 0.16);
            border-radius: 10px;
            padding: 40px;
        }

        .login-form {
            width: 100%;
        }

        .login-head {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
            font-size: 24px;
        }

        .login-head i {
            margin-right: 10px;
            color: #4e73df;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .control-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }

        .form-control {
            width: 100%;
            height: 45px;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: #4e73df;
            box-shadow: 0 0 0 2px rgba(78, 115, 223, 0.25);
        }

        .utility {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .animated-checkbox label {
            display: flex;
            align-items: center;
            cursor: pointer;
            color: #555;
        }

        .animated-checkbox input {
            margin-right: 8px;
            width: 16px;
            height: 16px;
        }

        .semibold-text {
            font-weight: 600;
            margin: 0;
        }

        .semibold-text a {
            color: #4e73df;
            text-decoration: none;
        }

        .semibold-text a:hover {
            text-decoration: underline;
        }

        .btn-container {
            margin-top: 30px;
        }

        .btn-primary {
            width: 100%;
            height: 45px;
            background-color: #4e73df;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-primary:hover {
            background-color: #2e59d9;
        }

        .btn-primary i {
            margin-right: 10px;
        }
    </style>
  </head>
  <body>
    <section class="material-half-bg">
      <div class="cover"></div>
    </section>
    <section class="registration-content">
      <div class="logo">
        <h1>OTP CODE</h1>
      </div>
     <div class="registration-box">
    <form class="login-form" action="index.html">
        <h3 class="login-head">
           <i class="fa fa-shield fa-lg fa-fw" style="color: black;"></i></i> Forgot Password ?
        </h3>
        
        <div class="form-group">
            <label class="control-label">User Email</label>
            <input class="form-control" id="email" type="email" placeholder="User Email">
        </div>
       
        <div class="form-group btn-container">
            <button type="button" onclick="VerifyEmail()" class="btn btn-primary btn-block" style="background-color: #009688; border: none;">
                <i class="fa fa-paper-plane fa-fw" style="color: black; font-size: 25px;"></i>
                SEND OTP
            </button>
        </div>
    </form>
</div>

    </section>
    <!-- Essential javascripts for application to work-->
    <script src="{{asset('backend/asset/js/jquery-3.2.1.min.js')}}"></script>
    <script src="{{asset('backend/asset/js/popper.min.js')}}"></script>
    <script src="{{asset('backend/asset/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('backend/asset/js/main.js')}}"></script>
        <script src="{{asset('backend/asset/js/loader.js')}}"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="{{asset('backend/asset/js/plugins/pace.min.js')}}"></script>

<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
async function VerifyEmail(){
    let email = document.getElementById('email').value;

    if(email.length === 0){
        return Swal.fire('Error', 'Email is Required', 'error');
    } else {
        try {
            let res = await axios.post('/userSend-otp', { email: email });

            if(res.status === 200 && res.data['status'] === 'success'){
                Swal.fire({
                    icon: 'success',
                    title: 'OTP Sent',
                    text: res.data['message'],
                    timer: 2000,
                    showConfirmButton: false
                });
                sessionStorage.setItem('email', email);
                setTimeout(function(){
                    window.location.href = "";
                }, 1000);
            } else {
                Swal.fire('Error', res.data['message'], 'error');
            }
        } catch (error) {
            Swal.fire(
                'Error',
                error.response?.data?.message || 'Something went wrong',
                'error'
            );
        }
    }
}
</script>

    
  </body>
</html>