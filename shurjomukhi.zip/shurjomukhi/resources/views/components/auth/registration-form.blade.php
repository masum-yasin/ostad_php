<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="{{asset('backend/asset/css/main.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('backend/asset/css/progress.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('backend/asset/css/toastify.min.css')}}">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Register Form</title>
    <style>
      
        
        .material-half-bg {
            position: fixed;
            width: 100%;
            height: 100%;
            background: url('your-background-image.jpg') center/cover no-repeat;
            z-index: -1;
            background-color: #009688;
        }
        
        .material-half-bg .cover {
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }
        
        .registration-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            width: 100%;
            padding: 20px;
            box-sizing: border-box;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 20px;
        }
        
        .logo h1 {
            color: #fff;
            font-size: 32px;
        }
        
        .registration-box {
            width: 100%;
            max-width: 500px;
            background-color: #fff;
            box-shadow: 0px 29px 147.5px 102.5px rgba(0, 0, 0, 0.05), 
                        0px 29px 95px 0px rgba(0, 0, 0, 0.16);
            border-radius: 10px;
            padding: 40px;
        }

        .login-form {
            width: 100%;
        }

        .login-head {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
            font-size: 24px;
        }

        .login-head i {
            margin-right: 10px;
            color: #4e73df;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .control-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }

        .form-control {
            width: 100%;
            height: 45px;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: #4e73df;
            box-shadow: 0 0 0 2px rgba(78, 115, 223, 0.25);
        }

        .utility {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .animated-checkbox label {
            display: flex;
            align-items: center;
            cursor: pointer;
            color: #555;
        }

        .animated-checkbox input {
            margin-right: 8px;
            width: 16px;
            height: 16px;
        }

        .semibold-text {
            font-weight: 600;
            margin: 0;
        }

        .semibold-text a {
            color: #4e73df;
            text-decoration: none;
        }

        .semibold-text a:hover {
            text-decoration: underline;
        }

        .btn-container {
            margin-top: 30px;
        }

        .btn-primary {
            width: 100%;
            height: 45px;
            background-color: #4e73df;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-primary:hover {
            background-color: #2e59d9;
        }

        .btn-primary i {
            margin-right: 10px;
        }
    </style>
  </head>
  <body>
    <section class="material-half-bg">
      <div class="cover"></div>
    </section>
    <section class="registration-content">
      <div class="logo">
        <h1>Register Form</h1>
      </div>
      <div class="registration-box">
        <form class="login-form" action="index.html">
          <h3 class="login-head">
    <i class="fa fa-lg fa-fw fa-user-plus" style="color: black;"></i> REGISTER</h3>

            <div class="form-group">
                <label class="control-label">First Name</label>
                <input class="form-control"  id="firstName" type="text" placeholder="User Name" autofocus>
            </div>
            <div class="form-group">
                <label class="control-label">Last Name</label>
                <input class="form-control" id="lastName"  type="text" placeholder="User Name" autofocus>
            </div>
            <div class="form-group">
                <label class="control-label">EMAIL</label>
                <input class="form-control" id="email" type="email" placeholder="Email" autofocus>
            </div>
            <div class="form-group">
                <label class="control-label">Mobile</label>
                <input class="form-control" id="mobile" type="mobile" placeholder="Mobile" autofocus>
            </div>
            <div class="form-group">
                <label class="control-label">PASSWORD</label>
                <input class="form-control" id="password" type="password" placeholder="Password">
            </div>
           
            <div class="form-group">
                <div class="utility">
                    <div class="animated-checkbox">
                        <label>
                            <input type="checkbox"><span class="label-text">I agree to the terms</span>
                        </label>
                    </div>
                </div>
            </div>
           <div class="form-group btn-container">
    <button type="button" onclick="onRegistration()" class="btn btn-primary btn-block" style="background-color: #009688; border: none;">
        <i class="fa fa-sign-in fa-lg fa-fw" style="color: black; font-size: 25px;"></i>
 REGISTER
    </button>
</div>

            <div class="form-group text-center">
                <p class="semibold-text">Already have an account? <a href="#">Login</a></p>
            </div>
        </form>
    </div>
    </section>
    <!-- Essential javascripts for application to work-->
    <script src="{{asset('backend/asset/js/jquery-3.2.1.min.js')}}"></script>
    <script src="{{asset('backend/asset/js/popper.min.js')}}"></script>
    <script src="{{asset('backend/asset/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('backend/asset/js/main.js')}}"></script>
        <script src="{{asset('backend/asset/js/loader.js')}}"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="{{asset('backend/asset/js/plugins/pace.min.js')}}"></script>
    

<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
        // Form submission handler
        document.getElementById('profileForm').addEventListener('submit', async function(event) {
            event.preventDefault();
            await updateProfile();
        });

        async function updateProfile() {
            // Get form values
            let fName = document.getElementById('fName').value.trim();
            let lName = document.getElementById('lName').value.trim();
            let email = document.getElementById('email').value.trim();
            let mobile = document.getElementById('mobile').value.trim();

            // Validation
            if (!fName) {
                await showError("First Name is required");
                return;
            }
            
            if (!lName) {
                await showError("Last Name is required");
                return;
            }
            
            if (!email) {
                await showError("Email is required");
                return;
            }
            
            if (!mobile) {
                await showError("Mobile Number is required");
                return;
            }

            // Email format validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                await showError("Please enter a valid email address");
                return;
            }

            try {
                // Show loading indicator
                Swal.fire({
                    title: 'Updating Profile',
                    text: 'Please wait...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                // Make API request
                let res = await axios.post("/user-update", {
                    firstName: fName,
                    lastName: lName, // Fixed the capital 'L' to match your backend
                    email: email,
                    mobile: mobile
                });

                // Close loading indicator
                Swal.close();

                if (res.status === 200 && res.data.status === 'success') {
                    await Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: 'Profile updated successfully',
                        timer: 2000,
                        showConfirmButton: false
                    });
                    
                    // Redirect after success
                    window.location.href = "/user-profile";
                } else {
                    await showError("Profile update failed: " + (res.data.message || 'Unknown error'));
                }
            } catch (error) {
                Swal.close();
                
                if (error.response) {
                    // Server responded with error status
                    await showError(error.response.data.message || 'Profile update failed');
                } else if (error.request) {
                    // Request was made but no response received
                    await showError('Network error. Please check your connection.');
                } else {
                    // Something else happened
                    await showError('An unexpected error occurred.');
                }
            }
        }

        // Helper function to show error messages
        async function showError(message) {
            await Swal.fire({
                icon: 'error',
                title: 'Error',
                text: message,
                confirmButtonColor: '#3498db'
            });
        }
    </script>

  </body>
</html>