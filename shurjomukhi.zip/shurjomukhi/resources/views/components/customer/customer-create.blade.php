<!-- Modal -->
    <div class="modal fade animated zoomIn" id="create-modal_customer" tabindex="-1" role="dialog" aria-labelledby="createLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header" style="background-color:#17a2b8">
                    <h6 class="modal-title" id="createLabel">Create Category</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

               <div class="modal-body">
    <form id="save-form-customer">
        <div class="container">
            <div class="row">
                <!-- Customer Name Field -->
                <div class="col-12 p-1">
                    <label class="form-label">Customer Name *</label>
                    <input type="text" class="form-control" id="customerName" name="customerName" placeholder="Enter customer name" required>
                </div>
            </div>

            <div class="row">
                <!-- Phone Number Field -->
                <div class="col-12 p-1">
                    <label class="form-label">Phone Number</label>
                    <input type="text" class="form-control" id="phoneNumber" name="phoneNumber" placeholder="Enter phone number">
                </div>
            </div>

            <div class="row">
                <!-- Category Name Field -->
                <div class="col-12 p-1">
                    <label class="form-label">Email *</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" required>
                </div>
            </div>

            <div class="row">
                <!-- City Field -->
                <div class="col-12 p-1">
                    <label class="form-label">City *</label>
                    <input type="text" class="form-control" id="city" name="city" placeholder="Enter city">
                </div>
            </div>

            <div class="row">
                <!-- Email Field -->
                <div class="col-12 p-1">
                    <label class="form-label">Country *</label>
                    <input type="text" class="form-control" id="country" name="country" placeholder="Enter Country">
                </div>
            </div>

            <div class="row">
                <!-- Address Field -->
                <div class="col-12 p-1">
                    <label class="form-label">Address</label>
                    <input type="text" class="form-control" id="address" name="address" placeholder="Enter address">
                </div>
            </div>
        </div>
    </form>
</div>
<!-- Modal Footer with Close + Submit -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal" id="modal-close-btn">
                        Close
                    </button>
                    <button type="button" class="btn btn-primary" id="createSubmitBtnCustomer">
                        Submit
                    </button>
                </div>
            </div>
        </div>
      </div>

<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  // Send cookies with every axios request
  axios.defaults.withCredentials = true;

  document.getElementById('createSubmitBtnCustomer').addEventListener('click', async (event) => {
    event.preventDefault();

    // Get values from form
    const customerName = document.getElementById('customerName').value?.trim();
    const phoneNumber = document.getElementById('phoneNumber').value?.trim();
    const email = document.getElementById('email').value?.trim();
    const city = document.getElementById('city').value?.trim();
    const country = document.getElementById('country').value?.trim();
    const address = document.getElementById('address').value?.trim();

    // Validation
    if (!customerName) {
      return Swal.fire({icon:'error', title:'Oops...', text:'Customer name is required!'});
    }
    if (!email) {
      return Swal.fire({icon:'error', title:'Oops...', text:'Email is required!'});
    }
    if (!city) {
      return Swal.fire({icon:'error', title:'Oops...', text:'City is required!'});
    }
    if (!country) {
      return Swal.fire({icon:'error', title:'Oops...', text:'Country is required!'});
    }

    try {
      // Send Axios POST request to Laravel endpoint
      const res = await axios.post('/create-customer', {
        customerName,
        phoneNumber,
        email,
        city,
        country,
        address
      });

      // Success
      document.getElementById('modal-close-btn').click(); // close modal
      Swal.fire({ icon:'success', title:'Success!', text: res.data.message || 'Customer created successfully' });
      document.getElementById('save-form-customer').reset(); // reset form
      await getCustomList(); // refresh the customer list
    } catch (err) {
      // Error
      const msg = err?.response?.data?.message || 'An error occurred while creating the customer';
      Swal.fire({ icon:'error', title:'Error', text: msg });
      console.error('Create customer failed:', err?.response || err);
    }
  });
</script>



