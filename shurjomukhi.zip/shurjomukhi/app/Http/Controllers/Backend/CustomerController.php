<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use Exception;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

class CustomerController extends Controller
{
    public function CustomerPage(){
        return view('pages.dashboard.customer-page');
    }
    
public function CreateCustomer(Request $request)
{
    try {
        // Validate request
        $request->validate([
            'customerName' => 'required|string|max:255',
            'phoneNumber' => 'nullable|string|max:20',
            'email' => 'required|email|max:255',
            'city' => 'required|string|max:100',
            'country' => 'required|string|max:100',
            'address' => 'nullable|string|max:255',
        ]);

        // Verify JWT token
        $token = $request->cookie('token');
    Log::info('JWT Token: ' . $token); // Log the token for debugging
        if (!$token) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $key = env('JWT_KEY');
        $decoded = JWT::decode($token, new Key($key, 'HS256'));
        $userId = $decoded->userID ?? null;

        if (!$userId) {
            return response()->json(['message' => 'Not a valid user'], 401);
        }

        // Create customer
        $customer = new Customer();
        $customer->name = $request->customerName;
        $customer->mobile = $request->phoneNumber;
        $customer->email = $request->email;
        $customer->city = $request->city;
        $customer->country = $request->country;
        $customer->address = $request->address;
        $customer->user_id = $userId;
        $customer->save();

        return response()->json(['message' => 'Customer created successfully'], 201);

    } catch (ValidationException $ve) {
        // Handle validation errors
        return response()->json([
            'message' => 'Validation failed',
            'errors' => $ve->errors()
        ], 422);

    } catch (\Illuminate\Database\QueryException $qe) {
        // Handle database errors
        return response()->json([
            'message' => 'Database error',
            'error' => $qe->getMessage()
        ], 500);

    } catch (Exception $e) {
        // Handle all other exceptions
        return response()->json([
            'message' => 'Something went wrong',
            'error' => $e->getMessage()
        ], 500);
    }
}

public function CustomerListShow(Request $request){
    try {
        // Check for token
        $token = $request->cookie('token');
        if(!$token){
            return response()->json(['message' => 'Token not found'], 401);
        }

        // Decode token
        $key = env('JWT_KEY');
        $decoded = JWT::decode($token, new Key($key, 'HS256'));
        $user_id = $decoded->userID ?? null;

        if(!$user_id){
            return response()->json(['message'=> 'Not a valid user'], 401);
        }

        // Fetch customers for this user
        $customers = Customer::where('user_id', $user_id)->get();
     
        return response()->json($customers, 200);

    } catch (\Firebase\JWT\ExpiredException $e) {
        return response()->json(['message' => 'Token expired'], 401);
    } catch (\Firebase\JWT\SignatureInvalidException $e) {
        return response()->json(['message' => 'Invalid token signature'], 401);
    } catch (\Exception $e) {
        return response()->json([
            'message' => 'Failed to fetch customers',
            'error' => $e->getMessage()
        ], 500);
    }
}


public function CustomerDelete(Request $request){

    try {
        $token = $request->cookie('token');
        $key = env('JWT_KEY');
        if (!$token) {
            return response()->json(['error' => 'Token not found'], 401);
        }   
        // Decode JWT
        $decoded = JWT::decode($token, new Key($key, 'HS256'));
        $user_id = $decoded->userID;
        if (!$user_id) {
            return response()->json(['error' => 'Invalid user in token'], 401);
        }
        // Validate request
        $id = $request->input('id');
        if(!$id){
            return response()->json(['error' => 'Customer ID is required'], 400);
        }
        // Fetch customer
        $customer = Customer::where('id', $id)->where('user_id', $user_id)->first();
        // Log::info('Customer to be deleted: ', $customer ? $customer->toArray() : []); // Log customer for debugging
        if($customer){
            $customer->delete();
            return response()->json(['message' => 'Customer deleted successfully'], 200);
        } else {
            return response()->json(['error' => 'Customer not found or not authorized'], 404);
        }
    } catch (\Firebase\JWT\ExpiredException $e) {
        return response()->json(['error' => 'Token expired'], 401);
    } catch (\Firebase\JWT\SignatureInvalidException $e) {
        return response()->json(['error' => 'Invalid token signature'], 401);
    } catch (\Exception $e) {
        // Log the error for debugging
        Log::error('Customer Delete Error: '.$e->getMessage());
        return response()->json(['error' => 'Something went wrong: '.$e->getMessage()], 500);
    }       

    
}

public function CustomerEditId(Request $request){
    $token = $request->cookie('token');
    if (!$token) {
        return response()->json(['error' => 'User Token Not Found'], 400);
    }


    try {
        $key = env('JWT_KEY');
        $decoded = JWT::decode($token, new Key($key, 'HS256'));
        $user_id = $decoded->userID ?? null;

        if (!$user_id) {
            return response()->json(['error' => 'User Not Found'], 400);
        }
        

        $id = $request->input('id');
   
        if (!$id) {
            return response()->json(['error' => 'Customer ID Required'], 400);
        }

        $editCustomer = Customer::where('id', $id)
                                ->where('user_id', $user_id)
                                ->first();
       
        if (!$editCustomer) {
            return response()->json(['error' => 'Customer not found or not authorized'], 401);
        }

        // Return customer data
        return response()->json($editCustomer);

    } catch (\Exception $e) {
        return response()->json(['error' => 'Invalid token or server error', 'message' => $e->getMessage()], 500);
    }
}


public function CustomerUpdate(Request $request)
{
    // JWT from cookie
    $token = $request->cookie('token');
    if (!$token) {
        return response()->json(['error' => 'User Token Not Found'], 401);
    }

    try {
        $key = env('JWT_KEY');
        // Typo fix: HS256 (not SH256). Also Key class usage is new Key($key, 'HS256')
        $decoded = JWT::decode($token, new Key($key, 'HS256'));
        $user_id = $decoded->userID ?? null;
        if (!$user_id) {
            return response()->json(['error' => 'Valid User Not Found'], 401);
        }

        // Validate inputs
        $validator = Validator::make($request->all(), [
            'id'      => 'required|integer',
            'name'    => 'required|string|max:255',
            'email'   => 'required|email|max:255',
            'mobile'  => 'nullable|string|max:255',
            'city'    => 'nullable|string|max:255',
            'country' => 'nullable|string|max:255',
            'address' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => 'Validation failed', 'messages' => $validator->errors()], 422);
        }

        // Find customer owned by this user
        $customer = Customer::where('id', $request->input('id'))
            ->where('user_id', $user_id)
            ->first();

        if (!$customer) {
            return response()->json(['error' => 'Customer not found or not authorized'], 404);
        }

        // Update (make sure fillable set in Customer model)
        $customer->name    = $request->input('name');
        $customer->email   = $request->input('email');
        $customer->mobile  = $request->input('mobile');
        $customer->city    = $request->input('city');
        $customer->country = $request->input('country');
        $customer->address = $request->input('address');
        $customer->save();

       return response()->json([
    'success'  => true,  // ← This is what we're checking for
    'message'  => 'Customer updated successfully',
    'customer' => $customer
], 200);  // ← And this status code

    } catch (\Throwable $e) {
        return response()->json([
            'error'   => 'Invalid token or server error',
            'message' => $e->getMessage()
        ], 500);
    }
}




}
