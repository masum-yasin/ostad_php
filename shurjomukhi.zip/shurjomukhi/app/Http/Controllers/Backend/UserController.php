<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Helper\JWTToken;
use App\Mail\OTPMAIL;
use App\Models\User;
use Exception; // ✅ Add this at the top if not already
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
  public function UserRegistration(Request $request)
{
    try {
        // Optional: Validate input
        $request->validate([
            'firstName' => 'required|string|max:50',
            'lastName'  => 'required|string|max:50',
            'email'     => 'required|email|unique:users,email',
            'mobile'    => 'required|string|max:20',
            'password'  => 'required|string|min:6',
        ]);

        User::create([
            'firstName' => $request->input('firstName'),
            'lastName'  => $request->input('lastName'),
            'email'     => $request->input('email'),
            'mobile'    => $request->input('mobile'),
            //'password'  => $request->input('password'),

           'password' => Hash::make($request->input('password')),
        ]);

        return response()->json([
            'status' => "success",
            'message' => "User Registration Successfully",
        ], 201);

    } catch (Exception $e) { // ✅ Correct Exception type
        return response()->json([
            'status' => "failed",
            'message' => "User Registration Failed",
            'error' => $e->getMessage() // Optional: helpful for debugging
        ], 500);
    }
}




// public function UserLogin(Request $request) {
//     $user = User::where('email', $request->input('email'))->first();

//     if ($user !==null && $user && Hash::check($request->input('password'), $user->password)) {
//         $token = JWTToken::CreateToken($request->input('email'), $user->id);
      

//      return response()->json([
//     'status' => 'success',
//     'message' => 'Login successful'
// ])->cookie('token', $token, 60*24*30, '/', null, true, true, false, 'Strict');

//     } else {
//         return response()->json([
//             'status' => 'failed',
//             'message' => 'Invalid email or password'
//         ]);
//     }
// }

public function UserLogin(Request $request)
{
    $request->validate([
        'email' => 'required|email',
        'password' => 'required'
    ]);

    $user = User::where('email', $request->input('email'))->first();

    if ($user && Hash::check($request->input('password'), $user->password)) {
        $token = JWTToken::CreateToken($user->email, $user->id);

        // 30 days = 60 * 24 * 30 minutes
        return response()->json([
            'status'  => 'success',
            'message' => 'Login successful'
        ])->cookie(
            'token',
            $token,
            60*24*30,   // minutes
            '/',        // path
            null,       // domain (set if using subdomain: '.yourdomain.com')
            false,      // secure=false for HTTP local dev
            true,       // httpOnly
            false,      // raw
            'Lax'       // SameSite: Lax is safe for same-site XHR
        );
    }

    return response()->json([
        'status'  => 'failed',
        'message' => 'Invalid email or password'
    ], 401);
}



public function sendOTPCode(Request $request)
{
    $request->validate([
        'email' => 'required|email'
    ]);

    $email = $request->input('email');
    $otp = strval(rand(10000, 99999)); // Ensure string type
    
    $user = User::where('email', $email)->first();

    if (!$user) {
        return response()->json([
            'status' => 'failed',
            'message' => 'Email not registered'
        ], 404);
    }

    // Store as string
    $user->otp = $otp;
    $user->save();

    // Send email
    Mail::to($email)->send(new OTPMAIL($otp));

    return response()->json([
        'status' => "success",
        'message' => "5-digit OTP sent to your email",
        'otp' => $otp // Remove this in production - only for testing
    ]);
}


public function VerifyOTP(Request $request)
{
    $request->validate([
        'email' => 'required|email',
        'otp' => 'required|digits:5'
    ]);

    $email = $request->input('email');
    $otp = strval($request->input('otp')); // Ensure string type

    $user = User::where('email', $email)
              ->where('otp', strval($otp)) // Compare as strings
              ->first();

    if (!$user) {
        // Detailed error logging
        $exists = User::where('email', $email)->exists();
        Log::error('OTP Verification Failed', [
            'email' => $email,
            'input_otp' => $otp,
            'db_otp' => $exists ? User::where('email', $email)->value('otp') : null,
            'reason' => $exists ? 'OTP mismatch' : 'Email not found'
        ]);
        
        return response()->json([
            'status' => 'failed',
            'message' => 'Invalid OTP or email'
        ], 401);
    }

    // Check expiration (5 minutes)
    if ($user->updated_at->addMinutes(5)->isPast()) {
        return response()->json([
            'status' => 'failed',
            'message' => 'OTP has expired'
        ], 401);
    }

    // Reset OTP
    $user->otp = null;
    $user->save();

    // Generate token
    $token = JWTToken::CreateTokenForResetPassword($user->email);

    return response()->json([
        'status' => 'success',
        'message' => 'Verification successful',
        'token' => $token
    ]);
}






public function ResetPassword(Request $request)
{
    try {
        // Validate inputs
        $request->validate([
            'password' => 'required|min:8|confirmed',
        ]);

        // Get token from cookie
        $token = $request->cookie('token');
        
        if (!$token) {
            return response()->json([
                'status' => 'fail',
                'message' => 'Token not found. Please restart the password reset process.'
            ], 401);
        }

        // Decode the JWT token to get the email
        try {
            $key = env('JWT_KEY');
            $decoded = JWT::decode($token, new Key($key, 'HS256'));
            $email = $decoded->userEmail;
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'fail',
                'message' => 'Invalid or expired token. Please restart the password reset process.'
            ], 401);
        }

        $password = $request->input('password');

        // Hash the password before storing
        $hashedPassword = Hash::make($password);

        $updated = User::where('email', $email)
                     ->update(['password' => $hashedPassword]);

        if ($updated === 0) {
            return response()->json([
                'status' => 'fail',
                'message' => 'User not found or password unchanged'
            ], 404);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Password reset successfully'
        ])->cookie(cookie()->forget('token')) // Clear the token cookie
         ->cookie(cookie()->forget('user_email')); // Clear the email cookie

    } catch (\Exception $exception) {
        return response()->json([
            'status' => 'error',
            'message' => 'Password reset failed: ' . $exception->getMessage()
        ], 500);
    }
}

public function UserLogOut()
{
    return redirect()->route('login.page')->cookie('token', '', -1);
}


public function UserProfileUpdate(Request $request) {
    try {
        // Get token from cookie
        $token = $request->cookie('token');
        
        if (!$token) {
            return response()->json([
                'status' => 'error',
                'message' => 'Authentication token missing'
            ], 401);
        }
        
        // Decode JWT token
        $key = env('JWT_KEY');
        $decoded = JWT::decode($token, new Key($key, 'HS256'));
        $email = $decoded->userEmail;
        $user_id = $decoded->userID;
        
        // Validate input
        $validator = Validator::make($request->all(), [
            'firstName' => 'required|string|max:255',
            'lastName' => 'required|string|max:255',
            'mobile' => 'required|string|max:20',
            'password' => 'nullable|string|min:6|confirmed',
            'profileImage' => 'nullable|image|mimes:jpeg,png,jpg,gif'
        ], [
            'password.confirmed' => 'Password confirmation does not match.',
            'password.min' => 'Password must be at least 6 characters.',
        ]);
        
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }
        
        // Prepare update data
        $updateData = [
            'firstName' => $request->input('firstName'),
            'lastName' => $request->input('lastName'),
            'mobile' => $request->input('mobile'),
        ];
        
        // Handle password update if provided
        if ($request->has('password') && !empty($request->input('password'))) {
            $updateData['password'] = Hash::make($request->input('password'));
        }
        
        // Handle profile image upload
        if ($request->hasFile('profileImage')) {
            $image = $request->file('profileImage');
            $imageName = time() . '_' . $user_id . '.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('backend/asset/img/profile');
            
            // Create directory if it doesn't exist
            if (!file_exists($destinationPath)) {
                mkdir($destinationPath, 0755, true);
            }
            
            $image->move($destinationPath, $imageName);
            $updateData['photo'] = '/backend/asset/img/profile/' . $imageName;
            
            // Delete old image if it exists
            $user = User::where('email', $email)->where('id', $user_id)->first();
            if ($user->photo && file_exists(public_path($user->photo))) {
                unlink(public_path($user->photo));
            }
        }
        
        // Update user
        $updated = User::where('email', $email)
            ->where('id', $user_id)
            ->update($updateData);
            
        if ($updated) {
            return response()->json([
                'status' => 'success',
                'message' => 'User Profile Updated Successfully',
            ]);
        } else {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to update profile'
            ], 500);
        }
        
    } catch (Exception $e) {
        return response()->json([
            'status' => 'error',
            'message' => 'An error occurred: ' . $e->getMessage()
        ], 500);
    }
}

// Page show section

public function UserLoginPage(){
    
    return view('components.auth.login-form');
}

public function RegistrationPage(){

    return view('components.auth.registration-form');
}

public function PasswordResetPage(){

    return view('components.auth.reset-pass-form');
}

public function OtpSendPage(){

    return view('components.auth.send-otp-form');
}

public function OtpVerifyPage(){

    return view('components.auth.verify-otp-form');
}

public function UserProfilePage(Request $request)
{

    $email = $request->header('email');
    $id = $request->header('id');
$users= User::where('email', $email)->where('id', $id)->first();


    return view('components.admin_body.user_profile', compact('users'));
}



}
