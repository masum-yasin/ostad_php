<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Exception;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class CategoryController extends Controller
{
    public function CategoryPage(){

        return view('pages.dashboard.category-page');
    }

  public function CategoryListShow(Request $request)
{
    // Get the token from the cookie
    $token = $request->cookie('token');
    
    // Check if token is provided
    if (!$token) {
        return response()->json(['error' => 'Token is missing'], 400);
    }

    try {
        // Decode the token using the JWT_KEY from the .env file
        $key = env('JWT_KEY');
        $decoded = JWT::decode($token, new Key($key, 'HS256'));

        // Extract user information from the decoded token
        $user_id = $decoded->userID;


        // Check if user_id is valid
        if (!$user_id) {
            return response()->json(['error' => 'User ID is missing in token'], 400);
        }

        // Fetch categories for the specific user
        $categories = Category::where('user_id', $user_id)->get();

        // Return the categories as JSON response
        return response()->json($categories);

    } catch (\Exception $e) {
        // Log the error for debugging
        Log::error('JWT Decode Error: ' . $e->getMessage());

        // Return an error response if decoding fails
        return response()->json(['error' => 'Invalid or expired token'], 401);
    }
}


public function CreateCategory(Request $request)
{
    $token = $request->cookie('token');
    if (!$token) {
        return response()->json(['error' => 'Token is missing'], 400);
    }
    
    try {
        $key = env('JWT_KEY');
        $decoded = JWT::decode($token, new Key($key, 'HS256'));
        $user_id = $decoded->userID;
        
        if (!$user_id) {
            return response()->json(['error' => 'User ID is missing in token'], 400);
        }
        
        $category = new Category();
        $category->name = $request->input('category');
        $category->user_id = $user_id;
        $category->save();
        
        return response()->json(['message' => 'Category created successfully'], 201);
        
    } catch (Exception $e) {
        return response()->json(['error' => 'Invalid token or server error'], 500);
    }
}

public function CategoryDelete(Request $request)
{
    try {
        $token = $request->cookie('token');
        $key = env('JWT_KEY');

        if (!$token) {
            return response()->json(['error' => 'Token not found'], 401);
        }

        // Decode JWT
        $decoded = JWT::decode($token, new Key($key, 'HS256'));
        $user_id = $decoded->userID;

        if (!$user_id) {
            return response()->json(['error' => 'Invalid user in token'], 401);
        }

        // Validate request
        $id = $request->input('id');
        if (!$id) {
            return response()->json(['error' => 'Category ID is required'], 400);
        }

        // Fetch category
        $category = Category::find($id);
        if (!$category) {
            return response()->json(['error' => 'Category not found'], 404);
        }

        // Authorization check
        if ($category->user_id !== $user_id) {
            return response()->json(['error' => 'Not authorized to delete this category'], 403);
        }

        // Delete category
        $category->delete();

        return response()->json(['message' => 'Category deleted successfully'], 200);

    } catch (\Firebase\JWT\ExpiredException $e) {
        return response()->json(['error' => 'Token expired'], 401);
    } catch (\Firebase\JWT\SignatureInvalidException $e) {
        return response()->json(['error' => 'Invalid token signature'], 401);
    } catch (\Exception $e) {
        // Log the error for debugging
        Log::error('Category Delete Error: '.$e->getMessage());
        return response()->json(['error' => 'Something went wrong: '.$e->getMessage()], 500);
    }
}


public function CategoryEditId(Request $request)
{
    $token = $request->cookie('token');
    if (!$token) {
        return response()->json(['error' => 'Token is missing'], 400);
    }

    try {
        $key = env('JWT_KEY');
        $decoded = JWT::decode($token, new Key($key, 'HS256'));
        $user_id = $decoded->userID;

        if (!$user_id) {
            return response()->json(['error' => 'User ID is missing in token'], 400);
        }

        $id = $request->input('id');
        if (!$id) {
            return response()->json(['error' => 'Category ID is required'], 400);
        }

        $category = Category::where('id', $id)->where('user_id', $user_id)->first();
        if (!$category) {
            return response()->json(['error' => 'Category not found or access denied'], 404);
        }

        return response()->json($category);

    } catch (Exception $e) {
        return response()->json(['error' => 'Invalid token or server error'], 500);
    }

}


public function CategoryUpdate(Request $request)
{
    try {
        // Validate token
        $token = $request->cookie('token');
        if (!$token) {
            return response()->json([
                'success' => false,
                'message' => 'Token is missing'
            ], 400);
        }

        // Decode token
        $key = env("JWT_KEY");
        $decoded = JWT::decode($token, new Key($key, 'HS256'));
        $user_id = $decoded->userID;
        
        if (!$user_id) {
            return response()->json([
                'success' => false,
                'message' => 'User ID is missing in token'
            ], 400);
        }

        // Validate input
        $request->validate([
            'id' => 'required|integer',
            'name' => 'required|string|max:255'
        ]);

        $id = $request->input('id');
        $name = $request->input('name');

        // Find and update category
        $category = Category::where('id', $id)
            ->where('user_id', $user_id)
            ->first();

        if (!$category) {
            return response()->json([
                'success' => false,
                'message' => 'Category not found or access denied'
            ], 404);
        }

        // Update category
        $category->name = $name;
        $category->save();

        // Return success response
        return response()->json([
            'success' => true,
            'message' => 'Category updated successfully'
        ], 200);

    } catch (ValidationException $e) {
        return response()->json([
            'success' => false,
            'message' => 'Validation error',
            'errors' => $e->errors()
        ], 422);
    } catch (Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Server error: ' . $e->getMessage()
        ], 500);
    }
}

}