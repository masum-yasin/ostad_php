<?php

namespace App\Http\Controllers\Backend;

use App\Helper\JWTToken;
use App\Http\Controllers\Controller;
use App\Mail\OTPMAIL;
use App\Models\User;
use Illuminate\Http\Request;

use Exception; // ✅ Add this at the top if not already
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class UserRegistrationController extends Controller
{
//   public function UserRegistration(Request $request)
// {
//     try {
//         // Optional: Validate input
//         $request->validate([
//             'firstName' => 'required|string|max:50',
//             'lastName'  => 'required|string|max:50',
//             'email'     => 'required|email|unique:users,email',
//             'mobile'    => 'required|string|max:20',
//             'password'  => 'required|string|min:6',
//         ]);

//         User::create([
//             'firstName' => $request->input('firstName'),
//             'lastName'  => $request->input('lastName'),
//             'email'     => $request->input('email'),
//             'mobile'    => $request->input('mobile'),
//             //'password'  => $request->input('password'),

//            'password' => Hash::make($request->input('password')),
//         ]);

//         return response()->json([
//             'status' => "success",
//             'message' => "User Registration Successfully",
//         ], 201);

//     } catch (Exception $e) { // ✅ Correct Exception type
//         return response()->json([
//             'status' => "failed",
//             'message' => "User Registration Failed",
//             'error' => $e->getMessage() // Optional: helpful for debugging
//         ], 500);
//     }
// }

public function UserRegistration(Request $request)
{
    try {
        // Validate input
        $validatedData = $request->validate([
            'firstName' => 'required|string|max:50',
            'lastName' => 'required|string|max:50',
            'email' => 'required|email|unique:users,email',
            'mobile' => 'required|string|max:20',
            'password' => 'required|string|min:6',
            'terms' => 'required|accepted'
        ]);

        // Create user
        $user = User::create([
            'firstName' => $validatedData['firstName'],
            'lastName' => $validatedData['lastName'],
            'email' => $validatedData['email'],
            'mobile' => $validatedData['mobile'],
            'password' => Hash::make($validatedData['password']),
        ]);

        // Return success response
        return response()->json([
            'status' => "success",
            'message' => "Registration successful! You can now login.",
            'user' => $user // Optional
        ], 201);

    } catch (\Illuminate\Validation\ValidationException $e) {
        // Handle validation errors
        $errors = $e->errors();
        $firstError = reset($errors)[0];
        
        return response()->json([
            'status' => "failed",
            'message' => $firstError,
            'errors' => $errors
        ], 422);
        
    } catch (\Exception $e) {
        // Handle other exceptions
        return response()->json([
            'status' => "failed",
            'message' => "Registration failed. Please try again later.",
            'error' => $e->getMessage() // Only for debugging, remove in production
        ], 500);
    }
}

public function UserLogin(Request $request) {

    $user = User::where('email', $request->input('email'))->first();
    

    if ($user && Hash::check($request->input('password'), $user->password)) {
        $token = JWTToken::CreateToken($request->input('email'));

        return response()->json([
            'status' => 'success',
            'message' => 'Login successful',
            'token' => $token
        ]);
    } else {
        return response()->json([
            'status' => 'failed',
            'message' => 'Invalid email or password'
        ]);
    }
}


public function sendOTPCode(Request $request)
{
    $request->validate([
        'email' => 'required|email'
    ]);

    $email = $request->input('email');
    $otp = strval(rand(100000, 999999)); // Ensure string type
    
    $user = User::where('email', $email)->first();

    if (!$user) {
        return response()->json([
            'status' => 'failed',
            'message' => 'Email not registered'
        ], 404);
    }

    // Store as string
    $user->otp = $otp;
    $user->save();

    // Send email
    Mail::to($email)->send(new OTPMAIL($otp));

    return response()->json([
        'status' => "success",
        'message' => "6-digit OTP sent to your email",
        'otp' => $otp // Remove this in production - only for testing
    ]);
}


public function VerifyOTP(Request $request)
{
    $request->validate([
        'email' => 'required|email',
        'otp' => 'required|digits:6'
    ]);

    $email = $request->input('email');
    $otp = strval($request->input('otp')); // Ensure string type

    $user = User::where('email', $email)
              ->where('otp', strval($otp)) // Compare as strings
              ->first();

    if (!$user) {
        // Detailed error logging
        $exists = User::where('email', $email)->exists();
        Log::error('OTP Verification Failed', [
            'email' => $email,
            'input_otp' => $otp,
            'db_otp' => $exists ? User::where('email', $email)->value('otp') : null,
            'reason' => $exists ? 'OTP mismatch' : 'Email not found'
        ]);
        
        return response()->json([
            'status' => 'failed',
            'message' => 'Invalid OTP or email'
        ], 401);
    }

    // Check expiration (5 minutes)
    if ($user->updated_at->addMinutes(5)->isPast()) {
        return response()->json([
            'status' => 'failed',
            'message' => 'OTP has expired'
        ], 401);
    }

    // Reset OTP
    $user->otp = null;
    $user->save();

    // Generate token
    $token = JWTToken::CreateTokenForResetPassword($user->email);

    return response()->json([
        'status' => 'success',
        'message' => 'Verification successful',
        'token' => $token
    ]);
}


// public function resetPassword(Request $request)
// {
//     try {
//         $email = $request->header('email');
//         $password = $request->input('password');

//         // Keep the same update logic but add basic validation
//         User::where('email', '=', $email)
//                      ->update(['password' => $password]);

//         return response()->json([
//             'status' => 'success',
//             'message' => "Password Reset Successfully"
//         ]);

//     } catch (\Exception $exception) {
//         return response()->json([
//             'status' => 'fail',
//             'message' => 'Something went wrong'
//         ]);
//     }
// }

public function resetPassword(Request $request)
{
    try {
        // Validate inputs
        $request->validate([
            
            'password' => 'required|min:8'
        ]);

        $email = $request->header('email');
        $password = $request->input('password');

        // Hash the password before storing
        $hashedPassword = Hash::make($password);

        $updated = User::where('email', $email)
                     ->update(['password' => $hashedPassword]);

        if ($updated === 0) {
            return response()->json([
                'status' => 'fail',
                'message' => 'User not found or password unchanged'
            ], 404);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Password reset successfully'
        ]);

    } catch (\Exception $exception) {
        return response()->json([
            'status' => 'error',
            'message' => 'Password reset failed: ' . $exception->getMessage()
        ], 500);
    }
}

}