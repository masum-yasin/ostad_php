<?php

use App\Http\Controllers\Backend\CategoryController;
use App\Http\Controllers\Backend\CustomerController;
use App\Http\Controllers\backend\DashboardController;
use App\Http\Controllers\Backend\UserController;
use App\Http\Controllers\Backend\UserRegistrationController;
use App\Http\Middleware\TokenVarificationMiddleWare;
use App\Models\Category;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


// Web Api Route

// Authencation Api

Route::post('/user-registration',[UserController::class,'UserRegistration'])->name('user.registration');
Route::post('/user-login', [UserController::class, 'UserLogin'])->name('userlogin');
Route::post('/userSend-otp', [UserController::class, 'sendOTPCode'])->name('send.otp');
Route::post('/otp-varification', [UserController::class, 'VerifyOTP'])->name('otp.varification');
Route::post('/password-reset', [UserController::class, 'resetPassword'])->middleware([TokenVarificationMiddleWare::class]);
Route::get('/user-logout', [UserController::class, 'UserLogOut'])->name('user.logout');
Route::post('/user-update', [UserController::class, 'UserProfileUpdate'])->name('user.update');

// Category Api

Route::middleware([TokenVarificationMiddleWare::class])->group(function () {

    // Route to show category list
    Route::get('/get-category-list', [CategoryController::class, 'CategoryListShow'])->name('category.list.show');
    
    // Route to create a new category
    Route::post('/create-category', [CategoryController::class, 'CreateCategory'])->name('create.category');

    // Route to delete a category
    Route::post('/category-delete', [CategoryController::class, 'CategoryDelete'])->name('category.delete');
    Route::get('/category-edit-ById', [CategoryController::class, 'CategoryEditId'])->name('category.edit.byid');
    Route::post('/category-update', [CategoryController::class, 'CategoryUpdate'])->name('category.update');
});


Route::middleware([TokenVarificationMiddleWare::class])->group(function () {

    // Customer Api Routes

    // Route to create a new customer
    Route::post('/create-customer', [CustomerController::class, 'CreateCustomer'])->name('create.customer');
    Route::get('/get-customer-list', [CustomerController::class, 'CustomerListShow'])->name('customer.list.show');

    //Route to delete a customer
    Route::post('/customer-delete', [CustomerController::class, 'CustomerDelete'])->name('customer.delete');
    Route::get('/customer-edit-ById', [CustomerController::class, 'CustomerEditId'])->name('customer.edit.byid');
    Route::post('/customer-update', [CustomerController::class, 'CustomerUpdate'])->name('customer.update');
});

// pages Section
Route::get('/dashboard-page', [DashboardController::class, 'dashboardPage'])->name('dashboard.page')->middleware([TokenVarificationMiddleWare::class]);
Route::get('/',[UserController::class,'UserLoginPage'])->name('login.page');
Route::get('/registration-page', [UserController::class, 'RegistrationPage'])->name('registration.page');

Route::get('/password-reset', [UserController::class, 'PasswordResetPage'])->name('password.reset')->middleware([TokenVarificationMiddleWare::class]);
Route::get('/otp-send', [UserController::class, 'OtpSendPage'])->name('otp.send');

Route::get('/otp-verify', [UserController::class, 'OtpVerifyPage'])->name('otp.verify');

Route::get('user-profile',[UserController::class,"UserProfilePage"])->name('user.profile')->middleware([TokenVarificationMiddleWare::class]);

// Category Routes page

Route::get('/category-page', [CategoryController::class, 'CategoryPage'])->name('category.page')->middleware([TokenVarificationMiddleWare::class]);

// Customer Routes page
Route::get('/customer-page', [CustomerController::class, 'CustomerPage'])->name('customer.page')->middleware([TokenVarificationMiddleWare::class]);

