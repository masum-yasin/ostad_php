<!-- Modal -->
<div class="modal fade animated zoomIn" id="customer-update-modal" tabindex="-1" role="dialog" aria-labelledby="createLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">

      <div class="modal-header">
        <h6 class="modal-title" id="createLabel">Update Customer</h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">
        <form class="update-form-customer" id="ResetCustomer">
          <input type="hidden" class="customerid" name="id">

          <div class="mb-3">
            <label class="form-label">Customer Name *</label>
            <input type="text" class="form-control customername" name="customerName" placeholder="Enter customer name" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Phone Number</label>
            <input type="text" class="form-control mobile" name="phoneNumber" placeholder="Enter phone number">
          </div>

          <div class="mb-3">
            <label class="form-label">Email *</label>
            <input type="email" class="form-control email" name="email" placeholder="Enter Email" required>
          </div>

          <div class="mb-3">
            <label class="form-label">City *</label>
            <input type="text" class="form-control city" name="city" placeholder="Enter city">
          </div>

          <div class="mb-3">
            <label class="form-label">Country *</label>
            <input type="text" class="form-control country" name="country" placeholder="Enter Country">
          </div>

          <div class="mb-3">
            <label class="form-label">Address</label>
            <textarea class="form-control address" name="address" placeholder="Enter address" rows="3"></textarea>
          </div>
        </form>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" id="update-modal-close-btn">Close</button>
        <button type="button" class="btn btn-primary" id="updateSubmitBtn">Submit</button>
      </div>

    </div>
  </div>
</div>


<!-- libs -->
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    async function FillUpdateFormCustomer(id) {
  try {
    const modalEl = document.getElementById('customer-update-modal');
    const form = modalEl.querySelector('.update-form-customer');

    // Hidden field
    form.querySelector('.customerid').value = id;

    // Fetch data
    const res = await axios.get('/customer-edit-ById', { params: { id }, withCredentials: true });
    console.log("Response:", res.data);

    // Use res.data directly (if your API returns plain object)
    form.querySelector('.customername').value = res.data?.name ?? '';
    form.querySelector('.mobile').value       = res.data?.mobile ?? '';
    form.querySelector('.email').value        = res.data?.email ?? '';
    form.querySelector('.city').value         = res.data?.city ?? '';
    form.querySelector('.country').value      = res.data?.country ?? '';
    form.querySelector('.address').value      = res.data?.address ?? '';

    // Show modal
    if (window.bootstrap?.Modal) {
      new bootstrap.Modal(modalEl).show();
    } else if (window.$) {
      $('#customer-update-modal').modal('show');
    }

  } catch (err) {
    console.error(err);
    Swal.fire('Error', 'Failed to load customer data', 'error');
  }
}

</script>



<script>
document.getElementById('updateSubmitBtn').addEventListener('click', async () => {
  const modalEl = document.getElementById('customer-update-modal');
  const form = modalEl.querySelector('.update-form-customer');

  const payload = {
    id:      form.querySelector('.customerid').value,
    name:    form.querySelector('.customername').value.trim(),
    mobile:  form.querySelector('.mobile').value.trim(),
    email:   form.querySelector('.email').value.trim(),
    city:    form.querySelector('.city').value.trim(),
    country: form.querySelector('.country').value.trim(),
    address: form.querySelector('.address').value.trim(),
  };

  if (!payload.name || !payload.email) {
    Swal.fire('Warning', 'Name & Email are required', 'warning');
    return;
  }

  try {
    const res = await axios.post('/customer-update', payload, { withCredentials: true });
    console.log('Update response:', res.status, res.data);

    // Check for your API's specific success format
    const isSuccess = res.status === 200 && 
                     res.data && 
                     res.data.success === true;

    if (isSuccess) {
      // Show success message
      await Swal.fire({
        icon: 'success',
        title: 'Success',
        text: res.data.message || 'Customer updated successfully',
        timer: 1300,
        showConfirmButton: false
      });

      // Close modal
      if (window.bootstrap?.Modal) {
        const modalInstance = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
        modalInstance.hide();
      } else if (window.$) {
        $('#customer-update-modal').modal('hide');
      }

      // Refresh lists
      if (typeof getCustomList === 'function') {
        getCustomList();
      }
      if (typeof getAllCustomer === 'function') {
        getAllCustomer();
      }
    } else {
      const msg = res.data?.error || res.data?.message || 'Failed to update customer';
      Swal.fire('Error', msg, 'error');
    }
  } catch (e) {
    console.error('Error details:', e);
    const msg = e?.response?.data?.error || e?.response?.data?.message || 'Failed to update customer';
    Swal.fire('Error', msg, 'error');
  }
});

</script>




<?php /**PATH D:\xampp\htdocs\ostad_php\shurjomukhi\resources\views/components/customer/customer-update.blade.php ENDPATH**/ ?>