
<?php $__env->startSection('admin'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            color: #333;
            line-height: 1.6;
            padding: 20px;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .profile-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-bottom: 30px;
        }
        
        .profile-header {
            background: linear-gradient(120deg, #4b6cb7 0%, #182848 100%);
            padding: 30px;
            position: relative;
            height: 200px;
        }
        
        .profile-content {
            display: flex;
            padding: 0 30px 30px;
            position: relative;
            margin-top: -75px;
        }
        
        .user-details {
            flex: 1;
            padding-right: 30px;
        }
        
        .profile-img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            border: 5px solid white;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            margin-left: 30px;
            background: white;
            padding: 5px;
            object-fit: cover;
        }
        
        .user-info h2 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #2c3e50;
        }
        
        .user-info p {
            color: #7f8c8d;
            margin-bottom: 20px;
            font-size: 18px;
        }
        
        .user-stats {
            display: flex;
            gap: 20px;
            margin: 25px 0;
        }
        
        .stat {
            text-align: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 12px;
            flex: 1;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease;
        }
        
        .stat:hover {
            transform: translateY(-5px);
        }
        
        .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: #4b6cb7;
            display: block;
        }
        
        .stat-label {
            font-size: 14px;
            color: #7f8c8d;
        }
        
        .user-about {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 12px;
            margin: 20px 0;
        }
        
        .user-about h3 {
            color: #2c3e50;
            margin-bottom: 10px;
            font-size: 20px;
        }
        
        .tabs {
            display: flex;
            margin: 30px 0 20px;
            border-bottom: 2px solid #eaeaea;
        }
        
        .tab {
            padding: 15px 25px;
            font-size: 16px;
            font-weight: 600;
            color: #7f8c8d;
            cursor: pointer;
            transition: all 0.3s ease;
            border-bottom: 3px solid transparent;
        }
        
        .tab.active {
            color: #4b6cb7;
            border-bottom: 3px solid #4b6cb7;
        }
        
        .tab-content {
            display: none;
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .tab-content.active {
            display: block;
        }
        
        /* Table Styles */
        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .info-table th {
            background-color: #4b6cb7;
            color: white;
            text-align: left;
            padding: 15px;
            font-weight: 600;
        }
        
        .info-table tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        
        .info-table td {
            padding: 15px;
            border-bottom: 1px solid #eaeaea;
        }
        
        .info-table .field-name {
            font-weight: 600;
            color: #2c3e50;
            width: 30%;
        }
        
        /* Form Styles */
        .update-form {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-top: 20px;
        }
        
        .form-title {
            font-size: 24px;
            color: #2c3e50;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f1f1f1;
        }
        
        .form-row {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .form-group {
            flex: 1;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #2c3e50;
        }
        
        .form-control {
            width: 100%;
            padding: 14px;
            border: 2px solid #eaeaea;
            border-radius: 10px;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            border-color: #4b6cb7;
            outline: none;
            box-shadow: 0 0 0 3px rgba(75, 108, 183, 0.1);
        }
        
        .btn {
            padding: 14px 28px;
            background: #4b6cb7;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn:hover {
            background: #3a5999;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .btn i {
            margin-right: 8px;
        }
        
        @media (max-width: 768px) {
            .profile-content {
                flex-direction: column;
            }
            
            .user-details {
                padding-right: 0;
                margin-bottom: 30px;
            }
            
            .profile-img {
                margin: 0 auto 20px;
            }

            #profile-img {
                margin: 0 auto 20px;
            }
            
            .form-row {
                flex-direction: column;
                gap: 0;
            }
            
            .user-stats {
                flex-direction: column;
            }
        }
    </style>


 <div class="container">
        <!-- Profile Card -->
        <div class="profile-card">
            <div class="profile-header"></div>
            
            <div class="profile-content">
                <div class="user-details">
                    <div class="user-info">
                        <h2>Johnathan Davis</h2>
                        <p>Senior Frontend Developer</p>
                        
                        <div class="user-stats">
                            <div class="stat">
                                <span class="stat-value">247</span>
                                <span class="stat-label">Posts</span>
                            </div>
                            <div class="stat">
                                <span class="stat-value">3.2K</span>
                                <span class="stat-label">Followers</span>
                            </div>
                            <div class="stat">
                                <span class="stat-value">1.5K</span>
                                <span class="stat-label">Following</span>
                            </div>
                        </div>
                        
                        <div class="user-about">
                            <h3>About Me</h3>
                            <p>Frontend developer with over 8 years of experience specializing in React and Vue.js. Passionate about creating intuitive user experiences and clean code architecture.</p>
                        </div>
                    </div>
                </div>
                
                <img src="<?php echo e($users->photo ? asset($users->photo) : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80'); ?>" class="profile-img" alt="Profile Image">
            </div>
            
            <div class="tabs">
                <div class="tab active" data-tab="profile">Profile Info</div>
                <div class="tab" data-tab="settings">Update Profile</div>
            </div>
            
            <div class="tab-content active" id="profile">
                <table class="info-table">
                    <thead>
                        <tr>
                            <th colspan="2">Personal Information</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="field-name">Full Name</td>
                            <td><?php echo e($users->firstName); ?></td>
                        </tr>
                        <tr>
                            <td class="field-name">Last Name</td>
                            <td><?php echo e($users->lastName); ?></td>
                        </tr>
                        <tr>
                            <td class="field-name">Email Address</td>
                            <td><?php echo e($users->email); ?></td>
                        </tr>
                        <tr>
                            <td class="field-name">Phone Number</td>
                            <td><?php echo e($users->mobile); ?></td>
                        </tr>
                       
                        <tr>
                            <td class="field-name">Address</td>
                            <td>123 Main Street, New York, NY 10001</td>
                        </tr>
                    </tbody>
                </table>
                
            
            </div>
            
           <div class="tab-content" id="settings">
                <div class="update-form">
                    <h2 class="form-title">Update Profile Information</h2>
                    
                    <form id="profileForm" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="image-upload-container">
        <img id="imagePreview" 
             src="<?php echo e($users->photo ? asset($users->photo) : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80'); ?>" 
             class="image-preview rounded-circle" 
             alt="Profile Preview" 
             style="width: 150px; height: 150px; object-fit: cover;">
        
        <label for="profileImage" class="file-input-label">
            <i class="fas fa-camera"></i> Choose Image
        </label>
        <input type="file" id="profileImage" name="profileImage" class="file-input" accept="image/*">
        <div class="error-message" id="profileImageError"></div>
    </div>
    
    <div class="form-row">
        <div class="form-group">
            <label class="form-label">First Name</label>
            <input type="text" id="firstName" name="firstName" class="form-control" value="<?php echo e($users->firstName); ?>">
            <div class="error-message" id="firstNameError"></div>
        </div>
        <div class="form-group">
            <label class="form-label">Last Name</label>
            <input type="text" id="lastName" name="lastName" class="form-control" value="<?php echo e($users->lastName); ?>">
            <div class="error-message" id="lastNameError"></div>
        </div>
    </div>
    
    <div class="form-row">
        <div class="form-group">
            <label class="form-label">Email Address</label>
            <input type="email" readonly id="email" class="form-control" value="<?php echo e($users->email); ?>" disabled>
            <small style="color: #7f8c8d; font-size: 12px;">Email cannot be changed</small>
        </div>
        <div class="form-group">
            <label class="form-label">Phone Number</label>
            <input type="tel" id="mobile" name="mobile" class="form-control" value="<?php echo e($users->mobile); ?>">
            <div class="error-message" id="mobileError"></div>
        </div>
    </div>
    
    <div class="form-row">
        <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" id="password" name="password" class="form-control" placeholder="Password">
            <div class="error-message" id="passwordError"></div>
        </div>
        <div class="form-group">
            <label class="form-label">Confirm Password</label>
            <input type="password" id="password_confirmation" name="password_confirmation" class="form-control" placeholder="Confirm Password">
        </div>
    </div>

    <div class="btn-container">
        <button type="submit" class="btn"><i class="fas fa-save"></i> Update Profile</button>
    </div>
</form>
                </div>
            </div>
        </div>
    </div>

   

<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    // Tab functionality
document.addEventListener('DOMContentLoaded', function() {
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const target = tab.getAttribute('data-tab');
            
            // Remove active class from all tabs and contents
            tabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            // Add active class to current tab and content
            tab.classList.add('active');
            document.getElementById(target).classList.add('active');
        });
    });
    
    // Image preview functionality
    const profileImageInput = document.getElementById('profileImage');
    const imagePreview = document.getElementById('imagePreview');
    
    profileImageInput.addEventListener('change', function() {
        const file = this.files[0];
        resetError('profileImageError');
        
        if (file) {
            // Validate file type
            const validTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
            if (!validTypes.includes(file.type)) {
                showError('profileImageError', 'Please select a valid image (JPEG, PNG, JPG, GIF)');
                this.value = '';
                return;
            }
            
            // Validate file size (max 2MB)
            if (file.size > 2 * 1024 * 1024) {
                showError('profileImageError', 'Image size must be less than 2MB');
                this.value = '';
                return;
            }
            
            const reader = new FileReader();
            reader.onload = function(e) {
                imagePreview.src = e.target.result;
            }
            reader.readAsDataURL(file);
        }
    });
});

// Form validation and submission
document.getElementById('profileForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    
    // Get form values
    let firstName = document.getElementById('firstName').value.trim();
    let lastName = document.getElementById('lastName').value.trim();
    let mobile = document.getElementById('mobile').value.trim();
    let password = document.getElementById('password').value;
    let passwordConfirmation = document.getElementById('password_confirmation').value;
    let profileImage = document.getElementById('profileImage').files[0];
    
    // Reset error messages
    resetErrors();
    
    // Validate inputs
    let isValid = true;
    
    if (firstName.length === 0) {
        showError('firstNameError', 'First Name is required');
        isValid = false;
    }
    
    if (lastName.length === 0) {
        showError('lastNameError', 'Last Name is required');
        isValid = false;
    }
    
    if (mobile.length === 0) {
        showError('mobileError', 'Mobile Number is required');
        isValid = false;
    } else if (!isValidMobile(mobile)) {
        showError('mobileError', 'Please enter a valid mobile number');
        isValid = false;
    }
    
    if (password.length > 0) {
        if (password.length < 6) {
            showError('passwordError', 'Password must be at least 6 characters long');
            isValid = false;
        } else if (password !== passwordConfirmation) {
            showError('passwordError', 'Passwords do not match');
            isValid = false;
        }
    }
    
    if (!isValid) {
        await Swal.fire({
            icon: 'error',
            title: 'Validation Error',
            text: 'Please fix the errors in the form',
        });
        return;
    }
    
    // Show loading alert
    const swalInstance = Swal.fire({
        title: 'Updating Profile',
        text: 'Please wait...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    try {
        // Create form data for file upload
        const formData = new FormData();
        formData.append('firstName', firstName);
        formData.append('lastName', lastName);
        formData.append('mobile', mobile);
        
        if (password.length > 0) {
            formData.append('password', password);
            formData.append('password_confirmation', passwordConfirmation);
        }
        
        if (profileImage) {
            formData.append('profileImage', profileImage);
        }
        
        // Send update request
        const res = await axios.post("/user-update", formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || ''
            }
        });
        
        await swalInstance.close();
        
        if (res.status === 200 && res.data.status === 'success') {
            await Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: 'Profile updated successfully',
                timer: 2000,
                showConfirmButton: false
            });
            
            // Redirect after success
            window.location.reload();
        } else {
            throw new Error(res.data.message || 'Profile update failed');
        }
    } catch (error) {
        console.error('Update error:', error);
        
        let errorMessage = 'Profile update failed. Please try again.';
        
        if (error.response && error.response.data) {
            // Handle validation errors from server
            if (error.response.data.errors) {
                const errors = error.response.data.errors;
                for (const field in errors) {
                    const errorElementId = field + 'Error';
                    if (document.getElementById(errorElementId)) {
                        showError(errorElementId, errors[field][0]);
                    }
                }
                errorMessage = 'Please fix the validation errors';
            } else if (error.response.data.message) {
                errorMessage = error.response.data.message;
            }
        } else if (error.message) {
            errorMessage = error.message;
        }
        
        await Swal.fire({
            icon: 'error',
            title: 'Update Failed',
            text: errorMessage,
        });
    }
});

// Helper functions
function showError(elementId, message) {
    const errorElement = document.getElementById(elementId);
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    }
}

function resetError(elementId) {
    const errorElement = document.getElementById(elementId);
    if (errorElement) {
        errorElement.textContent = '';
        errorElement.style.display = 'none';
    }
}

function resetErrors() {
    const errorElements = document.querySelectorAll('.error-message');
    errorElements.forEach(element => {
        element.textContent = '';
        element.style.display = 'none';
    });
}

function isValidMobile(mobile) {
    // Basic mobile validation - adjust as needed
    const mobileRegex = /^[+]?[0-9\s\-()]{10,20}$/;
    return mobileRegex.test(mobile);
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.sidenav-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ostad_php\shurjomukhi\resources\views/components/admin_body/user_profile.blade.php ENDPATH**/ ?>