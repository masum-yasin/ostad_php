<div class="app-title">
    <div>
        <h1><i class="fa fa-th-list"></i> Customer Tables</h1>
        <p>Customer tables</p>
    </div>
    <ul class="app-breadcrumb breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
        <li class="breadcrumb-item">Tables</li>
        <li class="breadcrumb-item active"><a href="#">Customer Tables</a></li>
    </ul>
</div>

<div class="row" style="margin-bottom: 30px">
  
    <div class="col-md-12">
<div class="text-right mb-3" width="100%">
  <button type="button" class="btn btn-primary"
          data-toggle="modal" data-target="#create-modal_customer">
    Create
  </button>
</div>
<div class="tile">
            <h3 class="tile-title">Customer List</h3>
            <table class="table table-hover" id="TableData">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Customer Name</th>
                        <th>Phone Number</th>
                        <th>Email</th>
                        <th>City</th>
                        <th>Country</th>
                        <th>Address</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="TableList">
                    <!-- Customer data will be inserted here -->
                </tbody>
            </table>
        </div>
    </div>
</div>
   <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script>
  // Call the function to load the categories when the page loads
    getCustomList();
    async function getCustomList(){
        // Fetch customer list using Axios
        let res = await axios.get('/get-customer-list');
        let tableData = $("#TableData");
        let tableList = $("#TableList");

        // Destroy existing DataTable and clear the table
        tableData.DataTable().destroy();
        tableList.empty();

        // Loop through the data and create table rows
        res.data.forEach(function(item, index){
            let row = `
                <tr>
                    <td>${index + 1}</td>
                    <td>${item['name']}</td>
                    <td>${item['mobile']}</td>
                    <td>${item['email']}</td>
                    <td>${item['city']}</td>
                    <td>${item['country']}</td>
                    <td>${item['address']}</td>
                    <td>
    <div class="d-flex">
        <button data-id="${item['id']}" class="btn btn-sm btn-outline-success editBtnCustomer mr-2">Edit</button>
        <button data-id="${item['id']}" class="btn btn-sm btn-outline-danger deleteBtnCustomer">Delete</button>
    </div>
</td>
</tr>
`;
            tableList.append(row);
        });

        // Add event listeners for Edit and Delete buttons
    $('.editBtnCustomer').on('click', async function () {
    let id = $(this).data('id');
    await FillUpdateFormCustomer(id);
    $("#customer-update-modal").modal('show');
});


        $('.deleteBtnCustomer').on('click', function () {
            let id = $(this).data('id');
           
            $("#customer_delete-modal").modal('show');
            $("#customer_deleteID").val(id); // Set the category ID to be deleted
        });

        // Re-initialize DataTable after appending rows
        new DataTable('#TableData', {
            order: [[0, 'asc']],
            lengthMenu: [5, 10, 15, 20, 30]
        });
    }

  </script>
<?php /**PATH D:\xampp\htdocs\ostad_php\shurjomukhi\resources\views/components/customer/customer-list.blade.php ENDPATH**/ ?>