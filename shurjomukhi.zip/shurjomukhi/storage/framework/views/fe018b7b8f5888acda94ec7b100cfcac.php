<!-- Modal -->
    <div class="modal fade animated zoomIn" id="category-update-modal" tabindex="-1" role="dialog" aria-labelledby="createLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title" id="createLabel">Update Category</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

    <div class="modal-body">
  <form id="update-form">
    <div class="container">
      <div class="row">
        <div class="col-12 p-1">
          <label class="form-label">Category Name *</label>
          <input type="text" class="form-control" id="categoryNameUpdate" name="category">
          <input type="hidden" class="form-control mt-2" id="updateID" name="id">
        </div>
      </div>
    </div>
  </form>
</div>
<!-- Modal Footer with Close + Submit -->
  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal" id="update-modal-close-btn">
                        Close
                    </button>
                    <button type="button" class="btn btn-primary" id="updateSubmitBtn">
                        Submit
                    </button>
                </div>
            </div>
        </div>
      </div>

<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<script>
  async function FillUpdateForm(id) {
    try {
      // ঠিক আইডি ব্যবহার করুন
      document.getElementById('updateID').value = id;

      // GET query param পাঠাতে params ব্যবহার করুন
      const res = await axios.get('/category-edit-ById', { params: { id } });

      // সার্ভার থেকে name এলে ইনপুটে বসান
      document.getElementById('categoryNameUpdate').value = res.data?.name ?? '';
    } catch (err) {
      console.error(err);
      Swal.fire('Error', 'Failed to load category', 'error');
    }
  }

</script>

<script>
document.getElementById('updateSubmitBtn').addEventListener('click', async (event) => {
    event.preventDefault();
    
    // Get values
    const categoryName = document.getElementById('categoryNameUpdate').value.trim();
    const updateID = document.getElementById('updateID').value;
    
    // Validation
    if (!categoryName) {
        Swal.fire('Warning', 'Category name is required', 'warning');
        return;
    }
    
    try {
        // Make API call
        const res = await axios.post('/category-update', {
            id: updateID,
            name: categoryName
        });
        
        // Close modal
        document.getElementById('update-modal-close-btn').click();
        
        // Log the response for debugging
        console.log(res.data);  // Log the response to check the structure
        
        // Handle response
        if (res.status === 200 && res.data.success) {
            Swal.fire('Success', 'Category updated successfully', 'success');
           await getList(); 
        } else {
            Swal.fire('Error', res.data.message || 'Failed to update category', 'error');
        }
    } catch (error) {
        console.error('Update error:', error);
        Swal.fire('Error', 'An error occurred while updating the category', 'error');
    }
});


</script>



<?php /**PATH D:\xampp\htdocs\ostad_php\shurjomukhi\resources\views/components/category/category-update.blade.php ENDPATH**/ ?>