
<!-- Add these to your CSS to further enhance the modal -->
<style>
  /* Smooth fade and zoom-in animation */
  .fade, .modal-backdrop {
    transition: opacity 0.4s ease !important;
  }

  .modal-content {
    background-color: #f9f9f9; /* Light background color */
    border-radius: 10px; /* Rounded corners */
  }

  .modal-header {
    background-color: #17a2b8 !important; /* Red header */
    border-bottom: 2px solid #f8f9fa;
  }

  .modal-title {
    font-weight: bold;
    font-size: 1.5rem;
  }

  .modal-footer {
    border-top: 1px solid #f1f1f1;
  }

  .btn-light {
    background-color: #f1f1f1;
    color: #333;
    border-radius: 25px;
    transition: all 0.3s ease-in-out;
  }

  .btn-light:hover {
    background-color: #dcdcdc;
    color: #000;
  }

  .btn-danger {
    background-color: #e74c3c;
    color: white;
    border-radius: 25px;
    transition: all 0.3s ease-in-out;
  }

  .btn-danger:hover {
    background-color: #c0392b;
  }

  /* Adding Icon styles */
  .btn i {
    margin-right: 8px;
  }
</style>

<!-- FontAwesome Icons for Buttons -->
<script src="https://kit.fontawesome.com/a076d05399.js"></script>


<div class="modal fade animated zoomIn" id="customer_delete-modal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content rounded-3 shadow-lg border-0">

      <div class="modal-header text-white" style="background-color:#17a2b8;">
        <h5 class="modal-title" id="exampleModalLongTitle">Delete Category</h5>
        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body text-center">
        <h3 class="mt-3 text-warning">Are you sure?</h3>
        <p class="mb-4 text-muted">Once deleted, you cannot recover it.</p>
        <input type="hidden" id="customer_deleteID">
      </div>

      <div class="modal-footer justify-content-center">
        <button type="button" id="customer_delete-modal-close" class="btn btn-light mx-2" data-dismiss="modal">
          <i class="fas fa-times-circle"></i> Cancel
        </button>
        <button type="button" id="confirmDelete" class="btn btn-danger px-4" onclick="itemDelete()">
          <i class="fas fa-trash-alt"></i> Delete
        </button>
      </div>

    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
  async function itemDelete() {
    const id = document.getElementById('customer_deleteID').value.trim();

    if (!id) {
      return Swal.fire({
        title: 'Error!',
        text: 'Customer ID is required.',
        icon: 'error',
        confirmButtonText: 'Okay'
      });
    }

    // Close the modal immediately
    document.getElementById('customer_delete-modal-close').click();

    try {
      // Make the delete request
      const res = await axios.post('/customer-delete', { id:id });

      // Check if the response is successful
      if (res.status === 200) {
        Swal.fire({
          title: 'Success!',
          text: res.data.message,
          icon: 'success',
          confirmButtonText: 'Okay'
        });
        await getCustomList(); // Reload customer list
      }
    } catch (error) {
      // Handle any error during the request
      Swal.fire({
        title: 'Error!',
        text: error.response?.data?.error || 'Customer deletion failed.',
        icon: 'error',
        confirmButtonText: 'Okay'
      });
    }
  }
</script>

<?php /**PATH D:\xampp\htdocs\ostad_php\shurjomukhi\resources\views/components/customer/customer-delete.blade.php ENDPATH**/ ?>